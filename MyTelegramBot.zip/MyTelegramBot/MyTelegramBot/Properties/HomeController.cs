﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Numerics;
using Telegram.Bot;
using Telegram.Bot.Args;
using Telegram.Bot.Types.ReplyMarkups;

namespace FIrstBotASP.Controllers
{
    public class HomeController : Controller
    {
        // TelegramBotClient sinfidan obyekt hosil qilamiz
        // va unga Botfather orqali olgan tokenni
        // bog'laymiz
        private readonly TelegramBotClient client = new TelegramBotClient("1749972829:AAH7azyYKN83wuV3sByNWb3v4CC4oJXt8Ss");

        // HomePage
        public string Index()
        {
            // yangi event_handler yasaldi
            client.OnMessage += Xabar_Kelganda;

            //inline button bosilganda hosil
            // bo'ladigan event_handler 
            client.OnCallbackQuery += CallBack;

            // xabar kelishini tasdiqlash
            client.StartReceiving();

            return "Bot hozr ishlamoqda";
        }

           // callbackquery event_hand
           private async void CallBack(object sender, CallbackQueryEventArgs e)
           {
               if (e.CallbackQuery.Data == "lotkir")
               {
                await client
                      .SendTextMessageAsync(e.CallbackQuery.From.Id, lotinkril(Text));

                await client
                    .DeleteMessageAsync(e.CallbackQuery.From.Id, e.CallbackQuery.Message.MessageId);
                // await client
                //      .SendTextMessageAsync(e.CallbackQuery.From.Id, "Siz yuborgan matn Lotinchadan Krillchaga o\'girildi.\nBotdan yana foydalanish uchun matn yuboring!");


            }
                if (e.CallbackQuery.Data == "kirlot")
                {
                await client
                       .SendTextMessageAsync(e.CallbackQuery.From.Id, krillotin(Text));

                await client
                    .DeleteMessageAsync(e.CallbackQuery.From.Id, e.CallbackQuery.Message.MessageId);
                // await client
                //        .SendTextMessageAsync(e.CallbackQuery.From.Id, "Siz yuborgan matn Krillchadan Lotinchaga o\'girildi.\nBotdan yana foydalanish uchun matn yuboring!");

            }
           }

        String Text;
           // foydalanuvchu xabar yuborganda ishlaydi
           private async void Xabar_Kelganda(object sender, MessageEventArgs e)
           {
            //kegan xabat matni
            Text = e.Message.Text;
               // foydalanuvchi idsi
               long userId = e.Message.Chat.Id;

               // kelgan xabar idsi
               int msgId = e.Message.MessageId;

               if (e.Message.Type == Telegram.Bot.Types.Enums.MessageType.Text)
               {
                   // amallar
                   if (e.Message.Text == "/start")
                   {
                       // xabar yuborish
                       await client.SendTextMessageAsync(userId, "Assalomu alaykum botimizga xush kelibsiz!\nBotdan foydalanish uchun matn yuboring!", replyToMessageId: msgId);
                   }
                   if (e.Message.Text.Length>0 && e.Message.Text != "/start")
                   {
                       var markup = new InlineKeyboardMarkup(
                           new InlineKeyboardButton[][]
                           {
                   new InlineKeyboardButton[]
                   {
                       InlineKeyboardButton
                           .WithCallbackData(text: "Lotin-->Krill", callbackData: "lotkir"),

                       InlineKeyboardButton
                           .WithCallbackData(text: "Krill-->Lotin", callbackData: "kirlot")
                   }/*,
                   new InlineKeyboardButton[]
                   {
                       InlineKeyboardButton
                           .WithCallbackData(text: "C", callbackData: "C bosildi"),
                       InlineKeyboardButton
                           .WithCallbackData(text: "D", callbackData: "D bosildi")
                   }*/
                           }
                       );

                       await client.SendTextMessageAsync(
                               chatId: userId,
                               text: "Tarjima turini tanlang",
                               replyMarkup: markup
                           );
                   }

           }
               else
                   await client.SendTextMessageAsync(userId, "Men faqat matnli xabarlarga javob qaytaraman", replyToMessageId: msgId);
           }

        //Krill-->Lotin funksiyasi
        public static string krillotin(string words)
        {
           words = words.Replace("ҳ", "h");
            words = words.Replace("Ҳ", "H");
           words = words.Replace("Ў", "O\'");
           words = words.Replace("ў", "o\'");
            words = words.Replace("ғ", "g\'");
            words = words.Replace("Ғ", "G\'");
            words = words.Replace("қ", "q");
            words = words.Replace("Қ", "Q");
           
            words = words.Replace("а", "a");
            words = words.Replace("б", "b");
            words = words.Replace("в", "v");
            words = words.Replace("г", "g");
            words = words.Replace("д", "d");
            words = words.Replace("е", "e");
            words = words.Replace("ё", "yo");
            words = words.Replace("ж", "j");
            words = words.Replace("з", "z");
            words = words.Replace("и", "i");
            words = words.Replace("й", "y");
            words = words.Replace("к", "k");
            words = words.Replace("л", "l");
            words = words.Replace("м", "m");
            words = words.Replace("н", "n");
            words = words.Replace("о", "o");
            words = words.Replace("п", "p");
            words = words.Replace("р", "r");
            words = words.Replace("с", "s");
            words = words.Replace("т", "t");
            words = words.Replace("у", "u");
            words = words.Replace("ф", "f");
            words = words.Replace("х", "x");
            words = words.Replace("ц", "ts");
            words = words.Replace("ч", "ch");
            words = words.Replace("ш", "sh");
            words = words.Replace("щ", "tsh");
            words = words.Replace("ъ", "`");
            words = words.Replace("ы", "i");
            words = words.Replace("ь", "");
            words = words.Replace("э", "e");
            words = words.Replace("ю", "yu");
            words = words.Replace("я", "ya");
            words = words.Replace("А", "A");
            words = words.Replace("Б", "B");
            words = words.Replace("В", "V");
            words = words.Replace("Г", "G");
            words = words.Replace("Д", "D");
            words = words.Replace("Е", "E");
            words = words.Replace("Ё", "Yo");
            words = words.Replace("Ж", "J");
            words = words.Replace("З", "Z");
            words = words.Replace("И", "I");
            words = words.Replace("Й", "Y");
            words = words.Replace("К", "K");
            words = words.Replace("Л", "L");
            words = words.Replace("М", "M");
            words = words.Replace("Н", "N");
            words = words.Replace("О", "O");
            words = words.Replace("П", "P");
            words = words.Replace("Р", "R");
            words = words.Replace("С", "S");
            words = words.Replace("Т", "T");
            words = words.Replace("У", "U");
            words = words.Replace("Ф", "F");
            words = words.Replace("Х", "X");
            words = words.Replace("Ц", "Ts");
            words = words.Replace("Ч", "Ch");
            words = words.Replace("Ш", "Sh");
            words = words.Replace("Щ", "TSh");
            words = words.Replace("Ъ", "`");
            words = words.Replace("Ы", "I");
            words = words.Replace("Ь", "");
            words = words.Replace("Э", "E");
            words = words.Replace("Ю", "Yu");
            words = words.Replace("Я", "Ya");
            
            return words;
        }

        //Lotin-->Krill funksiyasi
        public static string lotinkril(string Text)
        {
            string S = "";
            string f = ""; S = Text;
            BigInteger n = S.Length;
            S = S + "  ";
            for (int i = 0; i < n; i++)
            {
                char w, g = S[0];
                g = S[i];
                w = S[i + 1];
                switch (g)
                {
                    case 'q':
                        f = f + "қ";
                        break;
                    case 'g':
                        if (w == '`' || w.ToString() == "'" || w == 'ʼ' || w == 'ʻ')
                        {
                            f = f + "ғ";
                            i++;
                        }
                        else
                            f = f + "г";
                        break;

                    case 'e':
                        f = f + "е";
                        break;

                    case 'r':
                        f = f + "р";
                        break;

                    case 't':
                        f = f + "т";
                        break;

                    case 'y':
                        if (S[i + 2] != '`' || S[i + 2] != '\'' || S[i + 2] != 'ʻ' || S[i + 2] != 'ʼ')
                        {
                            if ((w.ToString().ToLower() == "o"))
                            {
                                f = f + "ё";
                                i++;
                                break;
                            }
                        }
                       else
                       if (S[i + 2] == '`' || S[i + 2] == '\'' || S[i + 2] == 'ʻ' || S[i + 2] == 'ʼ')
                            if ((w.ToString().ToLower() == "o"))
                            {
                                f = f + "йў";
                                i++;
                                break;
                            }
                        if ((w.ToString().ToLower() == "u"))
                        {
                            f = f + "ю";
                            i++;
                            break;
                        }
                        else
                        if ((w.ToString().ToLower() == "a"))
                        {
                            f = f + "я";
                            i++;
                            break;
                        }
                        else
                            f = f + "й";
                        break;

                    case 'u':
                        f = f + "у";
                        break;

                    case 'i':
                        f = f + "и";
                        break;

                    case 'o':
                        if ((w == '`') || w.ToString() == "'" || w == 'ʻ' || w == 'ʼ')
                        {
                            f = f + "ў";
                            i++;
                        }
                        else
                            f = f + "о";
                        break;

                    case 'p':
                        f = f + "п";
                        break;

                    case 'a':
                        f = f + "а";
                        break;

                    case 's':
                        if (w.ToString().ToLower() == "h")
                        {
                            f = f + "ш";
                            i++;
                        }
                        else
                            f = f + "с";
                        break;

                    case 'd':
                        f = f + "д";
                        break;

                    case 'f':
                        f = f + "ф";
                        break;

                    case 'j':
                        f = f + "ж";
                        break;

                    case 'k':
                        f = f + "к";
                        break;

                    case 'l':
                        f = f + "л";
                        break;

                    case 'z':
                        f = f + "з";
                        break;

                    case 'x':
                        f = f + "х";
                        break;

                    case 'v':
                        f = f + "в";
                        break;

                    case 'b':
                        f = f + "б";
                        break;
                    case 'n':
                        f = f + "н";
                        break;

                    case 'm':
                        f = f + "м";
                        break;

                    case 'h':
                        f = f + "ҳ";
                        break;

                    case 'c':
                        if (w.ToString().ToLower() == "h")
                        {
                            f = f + "ч";
                            i++;
                            break;
                        }
                        else
                            f += "C";
                        break;

                    case 'Q':
                        f = f + "Қ";
                        break;
                    case 'G':
                        if (w == '`' || w.ToString() == "'" || w == 'ʻ' || w == 'ʼ')
                        {
                            f = f + "Ғ";
                            i++;
                        }
                        else
                            f = f + "Г";
                        break;

                    case 'E':
                        f = f + "Е";
                        break;

                    case 'R':
                        f = f + "Р";
                        break;

                    case 'T':
                        f = f + "Т";
                        break;

                    case 'Y':
                        if (S[i + 2] != '`' || S[i + 2] != '\'' || S[i + 2] != 'ʻ' || S[i + 2] != 'ʼ')
                        {
                            if ((w.ToString().ToLower() == "o"))
                            {
                                f = f + "Ё";
                                i ++;
                                break;
                            }
                        }
                        else
                        if (S[i + 2] == '`' || S[i + 2] == '\'' || S[i + 2] == 'ʻ' || S[i + 2] == 'ʼ')
                            if ((w.ToString().ToLower() == "o"))
                                {
                                    f = f + "Йў";
                                    i++;
                                    break;
                                }
                        if ((w == 'u') || (w == 'U'))
                        {
                            f = f + "Ю";
                            i++;
                        }
                        if ((w == 'a') || (w == 'A'))
                        {
                            f = f + "Я";
                            i++;
                            break;
                        }
                        else
                            f = f + "Й";
                        break;

                    case 'U':
                        f = f + "У";
                        break;

                    case 'I':
                        f = f + "И";
                        break;

                    case 'O':
                        if (w == '`' || w.ToString() == "'" || w == 'ʻ' || w == 'ʼ')
                        {
                            f = f + "Ў";
                            i++;
                        }
                        else
                            f = f + "О";
                        break;

                    case 'P':
                        f = f + "П";
                        break;

                    case 'A':
                        f = f + "А";
                        break;

                    case 'S':
                        if (w.ToString().ToLower() == "h")
                        {
                            f = f + "Ш";
                            i++;
                        }
                        else
                            f = f + "С";
                        break;

                    case 'D':
                        f = f + "Д";
                        break;

                    case 'F':
                        f = f + "Ф";
                        break;

                    case 'J':
                        f = f + "Ж";
                        break;

                    case 'K':
                        f = f + "К";
                        break;

                    case 'L':
                        f = f + "Л";
                        break;

                    case 'Z':
                        f = f + "З";
                        break;

                    case 'X':
                        f = f + "Х";
                        break;

                    case 'V':
                        f = f + "В";
                        break;
                    case 'B':
                        f = f + "Б";
                        break;

                    case 'N':
                        f = f + "Н";
                        break;

                    case 'M':
                        f = f + "М";
                        break;

                    case 'H':
                        f = f + "Ҳ";
                        break;

                    case 'C':
                        if (w == 'H' || w == 'h')
                        {
                            f = f + "Ч";
                            i++;
                            break;
                        }
                        else
                            f += "C";
                        break;
                    case 'ʼ':
                        f += "ъ";
                        break;
                    case 'ʻ':
                        f += "ъ";
                        break;
                    case '`':
                        f += "ъ";
                        break;
                    case '\'':
                        f += "ъ";
                        break;
                    default:
                        f = f + g;
                        break;

                }

            }
            f = f.Replace("w", "в");
            f = f.Replace("W", "В");
            f = f.Replace("йе", "е");
            f = f.Replace("Йе", "Е");
            f = f.Replace("ЙЕ", "Е");
            f = f.Replace("ёъ", "йў");
            f = f.Replace("Ёъ", "Йў");
            return f;
        }




    }
}
